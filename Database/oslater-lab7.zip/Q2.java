import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  

import java.util.Random;
import java.util.Scanner;

public class Q2 
{

    public static void bookRoom() throws SQLException
    {
        Scanner inReader = new Scanner(System.in);

        System.out.println("Please enter the following fields so we can find a booking for you:");

        String q = "WITH getOccRooms as(\n" +
                    "Select distinct Room, RoomName, Beds, bedType, maxOcc, basePrice, decor from spaetau.lab7_reservations join lab7_rooms on RoomCode = Room  where (? <= Checkout AND ? >= CheckIn) AND ? <= Adults AND ? <= Kids)\n" +
                    "select distinct Room, RoomName, Beds, bedType, maxOcc, basePrice, decor from spaetau.lab7_reservations join lab7_rooms on RoomCode = Room\n" +
                    "where Room not in (select Room from getOccRooms)";

        System.out.println("First name:");
        String firstName = inReader.nextLine();

        System.out.println("Last name:");
        String lastName = inReader.nextLine();

        System.out.println("Room code (or 'Any' to specify no preference):");
        String roomCode = inReader.nextLine();
        if(!roomCode.equals("Any"))
            q += " AND Room = ?";

        System.out.println("Bed type (or 'Any' to specify no preference):");
        String bedType = inReader.nextLine();
        if(!bedType.equals("Any"))
            q += " AND bedType = ?";

        System.out.println("Begin date of stay (YYYY-MM-DD):");
        String startDate = inReader.nextLine();

        System.out.println("End date of stay (YYYY-MM-DD):");
        String endDate = inReader.nextLine();
        
        System.out.println("Number of children:");
        String numKid = inReader.nextLine();

        System.out.println("Number of adults:");
        String numAdult = inReader.nextLine();

        try (Connection conn = DriverManager.getConnection(System.getenv("HP_JDBC_URL"),
                                System.getenv("HP_JDBC_USER"),
                                System.getenv("HP_JDBC_PW"))) 
        {
            conn.setAutoCommit(false);

            String codeQ = "SELECT distinct CODE FROM spaetau.lab7_reservations";
            
            try (PreparedStatement bookStmt = conn.prepareStatement(q);
                Statement cStmt = conn.createStatement();
                ResultSet codeSet = cStmt.executeQuery(codeQ)) {


                LocalDate newS = LocalDate.parse(startDate);
                LocalDate newE = LocalDate.parse(endDate);

                bookStmt.setDate(1, java.sql.Date.valueOf(newS));
                bookStmt.setDate(2, java.sql.Date.valueOf(newE));
                bookStmt.setInt(3, Integer.parseInt(numAdult));
                bookStmt.setInt(4, Integer.parseInt(numKid));

                int count = 5;
                if(!roomCode.equals("Any"))
                {
                    bookStmt.setString(count, roomCode);
                    count++;
                }

                if(!bedType.equals("Any"))
                {
                    bookStmt.setString(count, bedType);
                    count++;
                }

                ResultSet bookSet = bookStmt.executeQuery();
                
                
                if(bookSet.next())
                {
                    bookSet.previous();

                    int z = 1;
                    System.out.println("Here are all the rooms that match what you're looking for:\n");
                    System.out.printf("%-5s%-10s%-30s%-10s%-10s%-10s%-15s%-10s\n", "", "Room", "RoomName", "Beds", "bedType", "maxOcc", "basePrice", "decor");

                    while(bookSet.next()){
                        String room = bookSet.getString("Room");
                        String roomName = bookSet.getString("RoomName");
                        String beds = bookSet.getString("Beds");
                        String bedTypeN = bookSet.getString("bedType");
                        String maxOcc = bookSet.getString("maxOcc");
                        String basePrice = bookSet.getString("basePrice");
                        String decor = bookSet.getString("decor");
                        System.out.printf("%-5s%-10s%-30s%-10s%-10s%-10s%-15s%-10s\n", z, room, roomName, beds,  bedTypeN, maxOcc, basePrice, decor);
                        z++;
                    }
                    System.out.println();
                    System.out.println("If you'd like to book one of these rooms, please enter the corrosponding number, or enter 'cancel' to quit:");
                    String selection = inReader.nextLine();
                    if(selection.equals("cancel"))
                        return;
                    
                    bookSet.beforeFirst();

                    for(int i = 0; i < Integer.parseInt(selection); i++)
                        bookSet.next();
                    String wantedRoom = bookSet.getString("Room");
                    String wantedRoomName = bookSet.getString("RoomName");
                    String wantedRate = bookSet.getString("basePrice");
                    String wantedbedType = bookSet.getString("bedType");

                    ArrayList<Integer> codeList = new ArrayList<>();
                    while(codeSet.next()){
                        codeList.add(codeSet.getInt("CODE"));
                    }
                    
                    Random rnd = new Random();
                    int newResCode = rnd.nextInt(99999);

                    while(codeList.contains(newResCode)){
                        newResCode = rnd.nextInt(99999);
                    }

                    String totDaysQ = "SELECT DATEDIFF(?, ?) as d";
                    String weekDaysQ = String.format("Select 5 * (DATEDIFF(?, ?) DIV 7) + MID('0123455501234445012333450122234501101234000123450', 7 * WEEKDAY(?) + WEEKDAY(?) + 1, 1) as d", endDate, startDate, startDate, endDate);

                    
                    String updateQ = String.format("INSERT INTO spaetau.lab7_reservations(CODE,Room,CheckIn,Checkout,Rate,LastName,FirstName,Adults,Kids) VALUES ('%s', '%s', ?, ?, '%s', ?, ?, ?, ?)", newResCode, wantedRoom, wantedRate);
                    try(PreparedStatement totDaysStmt = conn.prepareStatement(totDaysQ);
                        PreparedStatement weekDaysStmt = conn.prepareStatement(weekDaysQ);
                        PreparedStatement updateStmt = conn.prepareStatement(updateQ)){

                    totDaysStmt.setDate(1, java.sql.Date.valueOf(newE));
                    totDaysStmt.setDate(2, java.sql.Date.valueOf(newS));

                    weekDaysStmt.setDate(1, java.sql.Date.valueOf(newE));
                    weekDaysStmt.setDate(2, java.sql.Date.valueOf(newS));
                    weekDaysStmt.setDate(3, java.sql.Date.valueOf(newS));
                    weekDaysStmt.setDate(4, java.sql.Date.valueOf(newE));

                    updateStmt.setDate(1, java.sql.Date.valueOf(newS));
                    updateStmt.setDate(2, java.sql.Date.valueOf(newE));
                    updateStmt.setString(3, lastName);
                    updateStmt.setString(4, firstName);
                    updateStmt.setInt(5, Integer.parseInt(numAdult));
                    updateStmt.setInt(6, Integer.parseInt(numKid));
             
                    ResultSet wd = weekDaysStmt.executeQuery(weekDaysQ);
                    ResultSet dd = totDaysStmt.executeQuery(totDaysQ);

                    dd.next();
                    wd.next();
                      
                    double weekDays = wd.getDouble("d");
                    double weekEnds = dd.getDouble("d") - weekDays;

                    double total = (weekDays * Double.parseDouble(wantedRate)) + ((Double.parseDouble(wantedRate) * 1.10) * weekEnds);

                    System.out.println("Here is your reservation:");
                    System.out.println("First name: " + firstName);
                    System.out.println("Last name: " + lastName);
                    System.out.println("Room Code: " + wantedRoom);
                    System.out.println("Room Name: " + wantedRoomName);
                    System.out.println("Bed Type: " + wantedbedType);
                    System.out.println("Check In: " + startDate);
                    System.out.println("Checkout: " + endDate);
                    System.out.println("Number of adults: " + numAdult);
                    System.out.println("Number of children: " + numKid);
                    System.out.println("Total cost: " + Double.toString(total));
                    System.out.println("Would you like to confirm booking? Please enter 'y' or 'n'");
                    String confirm = inReader.nextLine();
                    if(!confirm.equals("y"))
                        return;
                   
                    updateStmt.executeUpdate();
                    System.out.println("Your reservation was booked");
                    conn.commit();
                    } catch (SQLException e) {
                    conn.rollback(); }
                    return;
                }

                System.out.println("No rooms matched what you are looking for.");

            conn.commit();
            } catch (SQLException e) {
             conn.rollback(); }
        }
    }
}
