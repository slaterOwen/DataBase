import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  


import java.util.Scanner;

public class Q5 {

    public static void searchReservation() throws SQLException
    {
        Scanner inReader = new Scanner(System.in);

        System.out.println("Please fill out the fields of what you want to search for, or enter 'Any' for no preference:");

        int weNeedAWhere = 0;

        String selectSql = "SELECT * from spaetau.lab7_reservations";
        String strToAppend = "";

        System.out.println("First name:");
        String firstName = inReader.nextLine();
        if(!firstName.equals("Any"))
        {
            weNeedAWhere = 1;
            strToAppend += " FirstName LIKE ? AND";
        }

        System.out.println("Last name:");
        String lastName = inReader.nextLine();
        if(!lastName.equals("Any"))
        {
            weNeedAWhere = 1;
            strToAppend += " LastName LIKE ? AND";
        }

        System.out.println("CheckIn date (YYYY-MM-DD):");
        String inDate = inReader.nextLine();
        if(!inDate.equals("Any"))
        {
            if(inDate.contains("%")){
                System.out.println("Cant do like with dates");
                return;
            }
            weNeedAWhere = 1;
            strToAppend += " CheckIn >= ? AND";
        }
        
        System.out.println("Checkout date (YYYY-MM-DD):");
        String outDate = inReader.nextLine();
        if(!outDate.equals("Any"))
        {
            if(outDate.contains("%")){
                System.out.println("Cant do like with dates");
                return;
            }
            weNeedAWhere = 1;
            strToAppend += " Checkout <= ? AND";
        }
        
        System.out.println("Room code:");
        String roomCode = inReader.nextLine();
        if(!roomCode.equals("Any"))
        {
            weNeedAWhere = 1;
            strToAppend += " Room LIKE ? AND";
        }
        
        System.out.println("Reservation code:");
        String resCode = inReader.nextLine();
        if(!resCode.equals("Any"))
        {
            weNeedAWhere = 1;
            strToAppend += " CAST(CODE as CHAR(5)) LIKE '?' AND";
        }

        if(weNeedAWhere == 1)
        {
            selectSql = selectSql + " WHERE" + strToAppend;
            selectSql = (selectSql.substring(0, selectSql.length() - 3));
        }

        System.out.println(selectSql);

        try (Connection conn = DriverManager.getConnection(System.getenv("HP_JDBC_URL"),
                                System.getenv("HP_JDBC_USER"),
                                System.getenv("HP_JDBC_PW"))) 
        {

            conn.setAutoCommit(false);


            try (PreparedStatement searchPstmt = conn.prepareStatement(selectSql))
            { 
                int count = 1;

                if(!firstName.equals("Any")){
                    searchPstmt.setString(count, firstName);
                    count++;
                }

                if(!lastName.equals("Any")){
                    searchPstmt.setString(count, lastName);
                    count++;
                }

                if(!inDate.equals("Any"))
                {
                    LocalDate newIn = LocalDate.parse(inDate);
                    searchPstmt.setDate(count, java.sql.Date.valueOf(newIn));
                    count++;
                }

                if(!outDate.equals("Any"))
                {
                    LocalDate newOut = LocalDate.parse(outDate);
                    searchPstmt.setDate(count, java.sql.Date.valueOf(newOut));
                    count++;
                }

                if(!roomCode.equals("Any")){
                    searchPstmt.setString(count, roomCode);
                    count++;
                }

                if(!resCode.equals("Any")){
                    searchPstmt.setInt(count, Integer.parseInt(resCode));
                    count++;
                }

                ResultSet searchSet = searchPstmt.executeQuery();

                while(searchSet.next())
                {
                    String LastN = searchSet.getString("LastName");
		            int res = searchSet.getInt("CODE");
                    System.out.println(LastN + " " + res);
                }

                conn.commit();
                } catch (SQLException e) {
                conn.rollback();
                }

        } 
    }
}