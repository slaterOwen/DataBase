import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  

import java.lang.Math;

import java.util.Scanner;

public class Q6 {

    public static void revenue() throws SQLException
    {

        String q = "WITH revs AS (SELECT Room, SUM(\n" + 
                    "(\n" + 
                    "DATEDIFF(CheckOut, CheckIn)\n" +
                    "-\n" +
                    "(IF(CheckOut <= LAST_DAY(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (2)-1 MONTH)), 0, 1)\n" +
                    "* DATEDIFF(CheckOut, DATE_ADD(LAST_DAY(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (2)-1 MONTH)), INTERVAL 1 DAY)))\n" +
                    "-\n" +
                    "(IF(CheckIn >= DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (2)-1 MONTH), 0, 1)\n" +
                    "* DATEDIFF(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (2)-1 MONTH), CheckIn))\n" +
                    ")\n" +
                    "* Rate\n" +
                    ")\n" +
                    "as Revenue\n" +
                    "FROM spaetau.lab7_reservations\n" +
                    "WHERE CheckIn <= LAST_DAY(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (2)-1 MONTH)) AND CheckOut >= DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (2)-1 MONTH)\n" +
                    "GROUP BY Room),\n" +
                    "rooms AS (SELECT Distinct Room FROM spaetau.lab7_reservations)\n" +
                    "SELECT ro.Room, IFNULL(Revenue, 0) revenue FROM revs re\n" +
                    "RIGHT JOIN rooms ro ON ro.Room = re.Room\n" +
                    "ORDER BY ro.Room";
        
        String numRoomS = "SELECT Count(distinct Room) as c from spaetau.lab7_reservations";

        try (Connection conn = DriverManager.getConnection(System.getenv("HP_JDBC_URL"),
                                System.getenv("HP_JDBC_USER"),
                                System.getenv("HP_JDBC_PW"))) 
        {   

            conn.setAutoCommit(false);

            try (Statement revStmt = conn.createStatement();
                 Statement numStmt = conn.createStatement()) 
            {
                ResultSet numSet = numStmt.executeQuery(numRoomS);
                numSet.next();
                int numRoom = numSet.getInt("c");

                float[][] revArray = new float[numRoom][12];
                String[] roomArr = new String[numRoom];

                for (int i = 1; i < 13; i++)
                {
                    int index = 0;
                    ResultSet revSet = revStmt.executeQuery(getRevMonth(Integer.toString(i)));
                    while(revSet.next())
                    {
                        String room = revSet.getString("Room");
                        float rev = revSet.getFloat("revenue");
                        revArray[index][i-1] = rev;
                        roomArr[index] = room;
                        index++;
                    }
                }

                System.out.printf("%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s%-6s\n", "Room", "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec", "Year");

                for(int x = 0; x < numRoom; x++)
                {   
                    int sum = 0;
                    System.out.printf("%-6s", roomArr[x]);
                    for(int i = 0; i < 12; i++)
                    {
                        System.out.printf("%-6s", Math.round(revArray[x][i]));
                        sum += revArray[x][i];
                    }
                    System.out.printf("%-6s\n", Math.round(sum));
                }


                System.out.printf("%-6s", "total");


                int totalSum = 0;
                for(int i = 0; i < 12; i++)
                {
                    int total = 0;
                    for(int x = 0; x < numRoom; x++)
                    {
                        total += revArray[x][i];
                        totalSum += revArray[x][i];
                    }
                    System.out.printf("%-6s", Math.round(total));
                }
                System.out.printf("%-6s\n\n", Math.round(totalSum));

            conn.commit();
            } catch (SQLException e) {
            conn.rollback(); }     
        }   



    }


    public static String getRevMonth(String i)
    {
        String q = "WITH revs AS (SELECT Room, SUM(\n" + 
                    "(\n" + 
                    "DATEDIFF(CheckOut, CheckIn)\n" +
                    "-\n" +
                    "(IF(CheckOut <= LAST_DAY(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (" + i + ")-1 MONTH)), 0, 1)\n" +
                    "* DATEDIFF(CheckOut, DATE_ADD(LAST_DAY(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (" + i + ")-1 MONTH)), INTERVAL 1 DAY)))\n" +
                    "-\n" +
                    "(IF(CheckIn >= DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (" + i + ")-1 MONTH), 0, 1)\n" +
                    "* DATEDIFF(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (" + i + ")-1 MONTH), CheckIn))\n" +
                    ")\n" +
                    "* Rate\n" +
                    ")\n" +
                    "as Revenue\n" +
                    "FROM spaetau.lab7_reservations\n" +
                    "WHERE CheckIn <= LAST_DAY(DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (" + i + ")-1 MONTH)) AND CheckOut >= DATE_ADD(MAKEDATE(YEAR(NOW()), 1), INTERVAL (" + i + ")-1 MONTH)\n" +
                    "GROUP BY Room),\n" +
                    "rooms AS (SELECT Distinct Room FROM spaetau.lab7_reservations)\n" +
                    "SELECT ro.Room, IFNULL(Revenue, 0) revenue FROM revs re\n" +
                    "RIGHT JOIN rooms ro ON ro.Room = re.Room\n" +
                    "ORDER BY ro.Room"; 
        return q;
    }
}