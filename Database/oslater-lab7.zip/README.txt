A)
Owen Slater - 3pm section
Soren Paetau - Noon section

B)

We wrote our lab to work with the command line of the shell.
We used Soren Paetau's database to set up and run the tables.

	1) In a new shell session, run "source auth.jdbc.TEMPLATE"
 	- This is for setting up the environment vriables. We used:
		export HP_JDBC_URL=jdbc:mysql://db.labthreesixfive.com/oslater?autoReconnect=true\&useSSL=false
		export HP_JDBC_USER=oslater
		export HP_JDBC_PW=wtr22_365-027071440
		export CLASSPATH=$CLASSPATH:mysql-connector-java-8.0.16.jar:.

	2) Run the command "javac *.java"

	3) Run the command "java InnReservations"

C)
For FR1, SAY is not always in our output; in our current dataset no stay has ever been completed 
in that room, while a left join would be ample with a "null" return, this seems clunky and unnecessary. 

Additionally, we make the assumption the user is aware of the use of LIKE operators and which entries 
they can enter "Any" or "No Change".

Currently the only bug we have is not finding any simular rooms when a user is looking to book a room
and no rooms are available to match their search.