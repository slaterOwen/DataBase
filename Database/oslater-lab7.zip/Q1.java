import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  


import java.util.Scanner;

public class Q1 {

    public static void popularRooms() throws SQLException
    {
        String q = "WITH foo AS (select Room, SUM(\n" +
                    "DATEDIFF(CheckOut, CheckIn) -\n" +
                    "(IF(CheckOut <= NOW(), 0, 1) * DATEDIFF(CheckOut, NOW())) -\n" +
                    "(IF(CheckIn >= DATE_SUB(NOW(), INTERVAL 180 DAY), 0, 1) * DATEDIFF(DATE_SUB(NOW(), INTERVAL 180 DAY), CheckIn))\n" +
                    ") /180 as popscore, MAX(CheckOut) as nextAvail\n" +
                    "from spaetau.lab7_reservations\n" +
                    "WHERE CheckIn <= NOW() AND CheckOut >= DATE_SUB(NOW(), INTERVAL 180 DAY)\n" +
                    "GROUP BY Room),\n" +
                    "bar AS (SELECT Room, MAX(CheckOut) CheckOut FROM spaetau.lab7_reservations\n" +
                    "WHERE CheckOut <= NOW()\n" +
                    "GROUP BY Room),\n" +
                    "scores AS (SELECT f.Room Room, popScore, nextAvail FROM bar r\n" +
                    "RIGHT JOIN foo f ON r.Room = f.Room\n" +
                    "),\n" +
                    "recent AS (SELECT Room, CheckOut outRecent, DATEDIFF(CheckOut, CheckIn) lengthRecent FROM spaetau.lab7_reservations r\n" +
                    "NATURAL JOIN bar)\n" +
                    "SELECT s.Room, RoomName, popscore, nextAvail, outRecent, lengthRecent, Beds, bedType, maxOcc, basePrice, decor FROM scores s\n" +
                    "LEFT JOIN recent r ON r.Room = s.Room\n" +
                    "JOIN lab7_rooms ON RoomCode = s.Room\n" +
                    "ORDER BY popscore DESC";

        try (Connection conn = DriverManager.getConnection(System.getenv("HP_JDBC_URL"),
                                System.getenv("HP_JDBC_USER"),
                                System.getenv("HP_JDBC_PW"))) {            

            conn.setAutoCommit(false);

            try (Statement popStmt = conn.createStatement()) {

                ResultSet popSet = popStmt.executeQuery(q);

                System.out.printf("%-15s%-15s%-20s%-20s%-20s%-15s%-15s%-15s%-15s%-15s%-15s\n","Rooms","Popularity","last recent stay", "Length last Stay", "Next available", "Beds", "Bed Type", "MaxOcc", "Base Price", "decor", "Room Name");

                while(popSet.next())
                {
                    String room = popSet.getString("Room");
                    String popS = popSet.getString("popscore");
                    String dateOfLastStay = popSet.getString("outRecent");
                    String lenLastStay = popSet.getString("lengthRecent");
                    String dateOfNextAvail = popSet.getString("nextAvail");
                    String beds = popSet.getString("Beds");
                    String bedType = popSet.getString("bedType");
                    int maxOcc = popSet.getInt("MaxOcc");
                    int basePrice = popSet.getInt("basePrice");
                    String decor = popSet.getString("decor");
                    String roomName = popSet.getString("RoomName");

                    System.out.printf("%-15s%-15s%-20s%-20s%-20s%-15s%-15s%-15s%-15s%-15s%-15s\n",room,popS,dateOfLastStay,lenLastStay,dateOfNextAvail,beds,bedType,Integer.toString(maxOcc),Integer.toString(basePrice),decor,roomName);

                }

                System.out.println();

            conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                }
        }
    }
}