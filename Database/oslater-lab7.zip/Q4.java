import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  


import java.util.Scanner;

public class Q4 {

    public static void cancelReservation() throws SQLException{
        
        Scanner inReader = new Scanner(System.in);

        System.out.println("Please input the reservation code of the reservation you'd like to cancel:");
        String resCode = inReader.nextLine();
        System.out.println("Are you sure you want to cancel the reservation for " + resCode + "?");
        System.out.println("Please put 'y' or 'n':");
        String response = inReader.nextLine();
        if(response.equalsIgnoreCase("y")) {
            try (Connection conn = DriverManager.getConnection(System.getenv("HP_JDBC_URL"),
                                System.getenv("HP_JDBC_USER"),
                                System.getenv("HP_JDBC_PW"))) {

            conn.setAutoCommit(false);

            String removeSql = "DELETE FROM spaetau.lab7_reservations WHERE CODE = ?;";
            
            try (PreparedStatement pstmt = conn.prepareStatement(removeSql)) {

            pstmt.setInt(1, Integer.parseInt(resCode));
            pstmt.executeUpdate();
            
            System.out.format("Removed reservation " + resCode + " from database\n");

            conn.commit();
            } catch (SQLException e) {
            conn.rollback();
            }}}
    }
}

