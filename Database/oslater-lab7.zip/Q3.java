import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  


import java.util.Scanner;

public class Q3 {
    
    public static void updateReservation() throws SQLException
    {

        Scanner inReader = new Scanner(System.in);

        System.out.println("Please input the reservation code of the reservation you'd like update:");
        String resCode = inReader.nextLine();

        try (Connection conn = DriverManager.getConnection(System.getenv("HP_JDBC_URL"),
                            System.getenv("HP_JDBC_USER"),
                            System.getenv("HP_JDBC_PW"))) {
        
        conn.setAutoCommit(false);

        String sql = "SELECT * FROM spaetau.lab7_reservations where CODE = ?;";            

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setInt(1, Integer.parseInt(resCode));
        ResultSet rs = pstmt.executeQuery();

        rs.next();
        String roomCode = rs.getString("Room");
        String ogCheckIn = rs.getString("CheckIn");
        String ogCheckout = rs.getString("Checkout");

        String updateSql = "UPDATE spaetau.lab7_reservations SET ";

        System.out.println("Please enter a new value for the fields you want to update.\n If you don't want to update a given field, please enter 'no change'");

        System.out.println("First Name:");
        String firstName = inReader.nextLine();
        if(!firstName.equals("no change"))
            updateSql += "FirstName = ?, ";

        System.out.println("Last Name:");
        String lastName = inReader.nextLine();
        if(!lastName.equals("no change"))
            updateSql += "LastName = ?, ";

        System.out.println("Begin date (YYYY-MM-DD):");
        String newBeginDate = inReader.nextLine();
        if(!newBeginDate.equals("no change"))
            updateSql += "CheckIn = ?, ";

        System.out.println("End date (YYYY-MM-DD):");
        String newEndDate = inReader.nextLine();
        if(!newEndDate.equals("no change"))
            updateSql += "Checkout = ?, ";

        System.out.println("Number of children:");
        String numChildren = inReader.nextLine();
        if(!numChildren.equals("no change"))
            updateSql += "Kids = ?, ";

        System.out.println("Number of adults:");
        String numAdults = inReader.nextLine();
        if(!numAdults.equals("no change"))
            updateSql += "Adults = ?, ";


        String checkSql = "SELECT * FROM spaetau.lab7_reservations where Room = ? AND Code != ? AND (";
        if(newBeginDate.equals("no change"))
            checkSql += " '" + ogCheckIn +"' <= Checkout AND";
        else
            checkSql += " ? <= Checkout AND";

        if(newEndDate.equals("no change"))
            checkSql += " '" + ogCheckout +"' >= CheckIn)";
        else
            checkSql += " ? >= CheckIn)";

        if(!newBeginDate.equals("no change") || !newEndDate.equals("no change"))
        {

            try (PreparedStatement checkPstmt = conn.prepareStatement(checkSql)) 
            {
                checkPstmt.setString(1, roomCode);
                checkPstmt.setInt(2, Integer.parseInt(resCode));

                int count = 3;

                if(!newBeginDate.equals("no change"))
                {
                    LocalDate newB = LocalDate.parse(newBeginDate);
                    checkPstmt.setDate(count, java.sql.Date.valueOf(newB));
                    count++;
                }

                if(!newEndDate.equals("no change"))
                {
                    LocalDate newE = LocalDate.parse(newEndDate);
                    checkPstmt.setDate(count, java.sql.Date.valueOf(newE));
                }

                ResultSet checkSet = checkPstmt.executeQuery();

                if(checkSet.next() == true){
                    System.out.println("Dates input overlap with other reservation");
                    return;
                }

                conn.commit();
            } catch (SQLException e) {
            conn.rollback();
            }
        }
        
        updateSql = (updateSql.substring(0, updateSql.length() - 2));
        updateSql = updateSql + " WHERE Code = ?";

        try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql))
        { 
            int count2 = 1;

            if(!firstName.equals("no change")){
                updatePstmt.setString(count2, firstName);
                count2++;
            }

            if(!lastName.equals("no change")){
                updatePstmt.setString(count2, lastName);
                count2++;
            }

            if(!newBeginDate.equals("no change")){
                LocalDate newB = LocalDate.parse(newBeginDate);
                updatePstmt.setDate(count2, java.sql.Date.valueOf(newB));
                count2++;
            }

            if(!newEndDate.equals("no change")){
                LocalDate newE = LocalDate.parse(newBeginDate);
                updatePstmt.setDate(count2, java.sql.Date.valueOf(newE));
                count2++;
            }

            if(!numChildren.equals("no change")){
                updatePstmt.setInt(count2, Integer.parseInt(numChildren));
                count2++;
            }

            if(!numAdults.equals("no change")){
                updatePstmt.setInt(count2, Integer.parseInt(numAdults));
                count2++;
            }

            updatePstmt.setInt(count2, Integer.parseInt(resCode));

            updatePstmt.executeUpdate();

            System.out.format("Updated reservation\n");

            conn.commit();
            } catch (SQLException e) {
            conn.rollback();
            }

            conn.commit();
            } catch (SQLException e) {
            conn.rollback();
            }
        }
    }
}
