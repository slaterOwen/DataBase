import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Map;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;  


import java.util.Scanner;

public class InnReservations {
    public static void main(String[] args) throws SQLException{

        int inputNum = 1;

        while (inputNum != 0) {
        System.out.println("Please select one of the following options by entering corrosponding number and pressing enter:\n");
        System.out.println("0: Quit.");
        System.out.println("1: Rooms and Rates.");
        System.out.println("2: Reservations.");
        System.out.println("3: Reservation Change.");
        System.out.println("4: Reservation Cancellation.");
        System.out.println("5: Detailed Reservation Information.");
        System.out.println("6: Revenue.");

        Scanner inReader = new Scanner(System.in);

        String input = inReader.nextLine();


        inputNum = Integer.parseInt(input);
            
            switch (inputNum) {
            case 0: System.out.println("Quit");
                    break;
            case 1: System.out.println("Rooms");
                    Q1.popularRooms();
                    break;
            case 2: System.out.println("Reservations");
                    Q2.bookRoom();
                    break;
            case 3: System.out.println("Reservation Change");
                    Q3.updateReservation();
                    break;
            case 4: System.out.println("Reservation Cancellation");
                    Q4.cancelReservation();
                    break;
            case 5: System.out.println("Detailed Reservation Information");
                    Q5.searchReservation();
                    break;
            case 6: System.out.println("Revenue");
                    Q6.revenue();
                    break;
            
	        } 
        }
    }
}